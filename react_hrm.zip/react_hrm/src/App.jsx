import { useState } from 'react'

import Layout from './Layout/Layout'
import CreateRole from './pages/roles/CreateRole'
import EditList from './pages/roles/EditList'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import RoleList from './pages/roles/RoleList'


import EmployInfo from './pages/roles/EmployInfo'
import UserList from './pages/users/UserList'
import CreateUser from './pages/users/CreateUser'
import DeptList from './pages/department/DeptList'
import CreateDept from './pages/department/CreateDept'
import EditUser from './pages/users/EditUser'






function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      
 <BrowserRouter>

      <Routes>
        <Route path="/" element={<Layout />} />


        <Route path="/role" element={<RoleList />} />
        <Route path="/role/edit/:roleId" element={<EditList />} />
        <Route path="/role/create" element={<CreateRole />} />
        <Route path="/employee" element={<EmployInfo />} />


        <Route path="/user" element={<UserList />} />
        <Route path="/user/create" element={<CreateUser />} />
        <Route path="/user/edit/:userId" element={<EditUser />} />


        <Route path="/department" element={<DeptList />} />
        <Route path="/department/create" element={<CreateDept />} />

         


      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
