import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditUser = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { userId } = useParams();

  const [user, setUser] = useState({
    username: "",
    password: "",
    email: "",
    address: ""
  });

  const navigate = useNavigate();

  // Fetch user data
  const fetchUser = () => {
    axios.get(`${baseUrl}/user/find/${userId}`)
      .then((res) => {
        console.log(res.data.user);
        setUser({
          username: res.data.user.username,
          password: res.data.user.password,
          email: res.data.user.email,
          address: res.data.user.address
        });
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchUser();
  }, []);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prev => ({ ...prev, [name]: value }));
  };

  // Submit updated user
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.put(`${baseUrl}/user/update`, user)
      .then((res) => {
        console.log(res.data);
        navigate("/user"); // Redirect to user list
      })
      .catch((err) => console.log(err));
  };

  return (
    <>
      <h3>Edit User</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Username</label>
          <input
            type="text"
            id="username"
            name="username"
            value={user.username}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={user.password}
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={user.email}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="address" className="form-label">Address</label>
          <input
            type="text"
            id="address"
            name="address"
            value={user.address}
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <button type="submit" className="btn btn-primary">Update User</button>
      </form>
    </>
  );
};

export default EditUser;
