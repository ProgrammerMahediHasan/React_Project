import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../Layout/Header';
import Footer from '../../Layout/Footer';

const UserList = () => {

  const getUsers = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/user",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.users);
        setUsers(res.data.users)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const [users, setUsers] = useState([]);

  useEffect (() => {getUsers()},[]);

  // Delete function 
  const deleteUser = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this user?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/user/delete",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.users);
        getUsers(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


  return (
    
<>

<Header />
  <h1 className="text-center my-4">Users Management</h1>

  <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-3">
          <Link to="/user/create" className="btn btn-success">
            Create New Role
          </Link>
        </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="table-dark">
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Username</th>
          <th scope="col">Password</th>
          <th scope="col">Email</th>
          <th scope="col">Address</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user, i) => (
          <tr key={i}>
            <th scope="row">{++i}</th>
            <td>{user.username}</td>
            <td>{user.password}</td>
            <td>{user.email}</td>
            <td>{user.address}</td>
            <td>
              <Link className="btn btn-info">Edit</Link>
              <a className="btn btn-danger" onClick={() => deleteUser(user.id)}>Delete</a>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  </div>
  <Footer />
</>


  );
};

export default UserList;
