import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateUser = () => {
  const [user, setUser] = useState({
    username: '',
    password: '',
    email: '',
    role_id: '',
    address: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting user:', user);

    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/user/save',
      method: 'POST',
      data: user
    })
      .then((res) => {
        console.log(res.data);
        if (res) {
          navigate('/user'); // redirect to user list after successful creation
        }
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1); // go to previous page
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Create User</h3>
      <form onSubmit={handleSubmit}>
        {/* Username */}
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Username</label>
          <input
            type="text"
            id="username"
            name="username"
            value={user.username}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter username"
            required
          />
        </div>

        {/* Password */}
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={user.password}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter password"
            required
          />
        </div>

        {/* Email */}
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={user.email}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter email"
            required
          />
        </div>

        {/* Role ID */}
        <div className="mb-3">
          <label htmlFor="role_id" className="form-label">Role ID</label>
          <input
            type="number"
            id="role_id"
            name="role_id"
            value={user.role_id}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter role ID"
            required
          />
        </div>

        {/* Address */}
        <div className="mb-3">
          <label htmlFor="address" className="form-label">Address</label>
          <input
            type="text"
            id="address"
            name="address"
            value={user.address}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter address"
            required
          />
        </div>

        {/* Submit Button */}
        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateUser;
