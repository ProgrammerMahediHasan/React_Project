import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../Layout/Header';
import Footer from '../../Layout/Footer';

const EmployInfo = () => {
  const [roles, setRoles] = useState([]);
  const getRoles = () => {
    axios({
      url: `${baseUrl}/role/employeeinfo`,
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.roles);
        setRoles(res.data.roles)
      })
      .catch((err) => {
        console.log(err);
      });
  }



  useEffect (() => {getRoles()},[]);

  // Delete function 
  const deleteRole = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this role?");
    if (!Delete) return;

    axios({
      url: `${baseUrl}/role/delete`,
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data);
        getRoles(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


  return (
    
<>
<Header />
  <h1 className="text-center my-4">Roles List</h1>
  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="table-dark">
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Name</th>
          <th scope="col">Created Time</th>
          <th scope="col">Updated Time</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {roles.map((role, i) => (
          <tr key={i}>
            <th scope="row">{++i}</th>
            <td>{role.name}</td>
            <td>{role.created_at}</td>
            <td>{role.updated_at}</td>
            <td>
              <Link to ={`/role/edit/${role.id}`} className="btn btn-info">Edit</Link>
              <a className="btn btn-danger" onClick={() => deleteRole(role.id)}>Delete</a>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
  <Footer />
</>


  );
};

export default EmployInfo;
