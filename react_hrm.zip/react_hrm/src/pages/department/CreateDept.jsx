import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateDept = () => {
  const [department, setDepartment] = useState({
    name: '',
    description: '',
    status: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDepartment((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting department:', department);

    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/department/save',
      method: 'POST',
      data: department
    })
      .then((res) => {
        console.log(res.data.department);
        if (res) {
          navigate('/department'); // redirect to user list after successful creation
        }
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1); // go to previous page
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Create Department</h3>
      <form onSubmit={handleSubmit}>
        {/* Username */}
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={department.name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter name"
            required
          />
        </div>

        {/* Password */}
        <div className="mb-3">
          <label htmlFor="description" className="form-label">description</label>
          <input
            type="description"
            id="description"
            name="description"
            value={department.description}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter description"
            required
          />
        </div>

        {/* Email */}
        <div className="mb-3">
          <label htmlFor="status" className="form-label">Status</label>
          <input
            type="status"
            id="status"
            name="status"
            value={department.status}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter status"
            required
          />
        </div>

        {/* Role ID */}
        {/* <div className="mb-3">
          <label htmlFor="role_id" className="form-label">Role ID</label>
          <input
            type="number"
            id="role_id"
            name="role_id"
            value={user.role_id}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter role ID"
            required
          />
        </div> */}

        {/* Address */}
        {/* <div className="mb-3">
          <label htmlFor="address" className="form-label">Address</label>
          <input
            type="text"
            id="address"
            name="address"
            value={user.address}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter address"
            required
          />
        </div> */}

        {/* Submit Button */}
        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateDept;
