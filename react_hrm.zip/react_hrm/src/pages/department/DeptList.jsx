import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../Layout/Header';
import Footer from '../../Layout/Footer';

const DeptList = () => {

  const getdepartment = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/department/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.department);
        setdepartment(res.data.department)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const [department, setdepartment] = useState([]);

  useEffect (() => {getdepartment()},[]);

  // Delete function 
  const deletedepartment = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this user?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/department/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.department);
        getdepartment(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


  return (
    
<>

<Header />
  <h1 className="text-center my-4">Department List</h1>

  <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/department/create" className="btn btn-success">
            Create New Role
          </Link>
        </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="table-dark">
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Name</th>
          <th scope="col">Description</th>
          <th scope="col">Status</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {department.map((dept, i) => (
          <tr key={i}>
            <th scope="row">{++i}</th>
            <td>{dept.name}</td>
            <td>{dept.description}</td>
            <td>{dept.status}</td>
            <td>
              <Link className="btn btn-info">Edit</Link>
              <a className="btn btn-danger" onClick={() => deletedepartment(dept.id)}>Delete</a>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  </div>
  <Footer />
</>


  );
};

export default DeptList;
