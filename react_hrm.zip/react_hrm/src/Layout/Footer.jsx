import React from 'react'

const Footer = () => {
  const footerStyle = {
    position: 'fixed',
    bottom: 0,
    left: 0,
    width: '100%',
    backgroundColor: '#2c2c2c',
    color: 'white',
    textAlign: 'center',
    padding: '0px 0px',
    zIndex: 1000,
    boxShadow: '0 -2px 10px rgba(0, 0, 0, 0.3)',
    fontSize: '15px',
    letterSpacing: '0.5px',
    fontWeight: 500,
  };

  return (
    <footer style={footerStyle}>
      <marquee behavior="right" direction="right"><p>© 2025 NextPrime Limited | All Rights Reserved. (Mahedi Hasan)</p></marquee>
    </footer>
  );
};

export default Footer;
